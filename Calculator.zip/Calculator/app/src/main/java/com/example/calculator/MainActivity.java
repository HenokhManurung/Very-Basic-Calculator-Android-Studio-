package com.example.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView result;
    private EditText input1 , input2;
    private Button tambah , kurang , bagi , kali ;
    float hasil;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        result = findViewById(R.id.Output);
        input1 = findViewById(R.id.input1);
        input2 = findViewById(R.id.input2);
        tambah = findViewById(R.id.tambah);
        kurang = findViewById(R.id.kurang);
        bagi = findViewById(R.id.bagi);
        kali = findViewById(R.id.kali);

        tambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               float num1 = Float.parseFloat(input1.getText().toString());
               float num2 = Float.parseFloat(input2.getText().toString());
                hasil = num1 + num2 ;
                result.setText(String.valueOf(hasil));
            }
        });

        kurang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float num1 = Float.parseFloat(input1.getText().toString());
                float num2 = Float.parseFloat(input2.getText().toString());
                hasil = num1 - num2 ;
                result.setText(String.valueOf(hasil));
            }
        });

        kali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float num1 = Float.parseFloat(input1.getText().toString());
                float num2 = Float.parseFloat(input2.getText().toString());
                hasil = num1 * num2 ;
                result.setText(String.valueOf(hasil));
            }
        });

        bagi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float num1 = Float.parseFloat(input1.getText().toString());
                float num2 = Float.parseFloat(input2.getText().toString());
                hasil = num1 / num2 ;
                result.setText(String.valueOf(hasil));
            }
        });

        }

    }

